package lecture01

// Example 2 - loop not executed
int i = 10
while(i < 5){
    i++
    println i
}

